README AARON ZHANG 23800511:
Runs out of box by typing python decision_tree.py . That will generate a text file containing test file labels. Also prints out some useful statistics to console.